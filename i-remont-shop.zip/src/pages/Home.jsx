export default function Home() {
  return (
    <div style={{ padding: 30 }}>
      <h1>i-Remont Shop</h1>
      <p>Интернет-магазин премиальных iPhone, Mac и гаджетов.</p>
    </div>
  );
}