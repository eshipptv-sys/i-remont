export default function Catalog() {
  return (
    <div style={{ padding: 30 }}>
      <h1>Каталог</h1>
      <p>Тут скоро появятся товары.</p>
    </div>
  );
}